import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BannerComponent } from './banner/banner.component';
import { HelpComponent } from './help/help.component';
import { OurProjectComponent } from './our-project/our-project.component';
import { BlackComponent } from './black/black.component';
import { EmergencyComponent } from './emergency/emergency.component';
import { SuccessComponent } from './success/success.component';
import { DonatorsComponent } from './donators/donators.component';
import { EventsComponent } from './events/events.component';
import { LatestPostsComponent } from './latest-posts/latest-posts.component';
import { FooterComponent } from './footer/footer.component';
// here
import {RouterModule , Route} from '@angular/router';
//editted sstart
const route:Route[]=[
  // {path:'home',component:HeaderComponent},
  {path:'home',component:BannerComponent},
  {path:'your-help',component:HelpComponent},
  {path:'our-projects',component:OurProjectComponent},
  //her 2 edit more
  {path:'collection', component:BlackComponent},
  {path:'emergency',component:EmergencyComponent},
  // till here
  {path:'sucess-stories',component:SuccessComponent},
  {path:'donators',component:DonatorsComponent},
  //here to
  {path:'events' , component:EventsComponent},
  //till here
  {path:'blogs-news',component:LatestPostsComponent},
  {path:'subscription',component:FooterComponent},
]

// editting end

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    BannerComponent,
    HelpComponent,
    OurProjectComponent,
    BlackComponent,
    EmergencyComponent,
    SuccessComponent,
    DonatorsComponent,
    EventsComponent,
    LatestPostsComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    RouterModule.forRoot(route)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
