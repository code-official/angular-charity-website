import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-black',
  templateUrl: './black.component.html',
  styleUrls: ['./black.component.css']
})
export class BlackComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
