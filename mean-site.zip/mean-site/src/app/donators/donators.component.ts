import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donators',
  templateUrl: './donators.component.html',
  styleUrls: ['./donators.component.css']
})
export class DonatorsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
